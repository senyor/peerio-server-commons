require('./underscore.array.builders');
require('./underscore.array.selectors');
require('./underscore.collections.walk');
require('./underscore.function.arity');
require('./underscore.function.combinators');
require('./underscore.function.dispatch');
require('./underscore.function.iterators');
require('./underscore.function.predicates');
require('./underscore.object.builders');
require('./underscore.object.selectors');
require('./underscore.util.existential');
require('./underscore.util.operators');
require('./underscore.util.strings');
require('./underscore.util.trampolines');

module.exports = require('underscore');
