### util.trampolines

> Trampoline functions.

Documentation should use [Journo](https://github.com/jashkenas/journo) formats and standards.

    done: function(value) {
    trampoline: function(fun /*, args */) {

--------------------------------------------------------------------------------