module.exports = {

  env: {
    browser: true,
  },

};
