// Coding standard for this project defined @ https://github.com/MatthewSH/standards/blob/master/JavaScript.md
const $rightpad = require('../rightpad');

console.log($rightpad('hello world', 14, '.')); // => hello world...
