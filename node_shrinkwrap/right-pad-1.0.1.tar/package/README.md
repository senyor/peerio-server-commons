# Right Pad
Right Pad adds a "padding" to the right side of the string with the character of your choice or just blank space.

## Install
`$ npm install right-pad`

## Usage
```javascript
var rightpad = require('right-pad');
rightpad('hello world', 14, '.'); // => hello world...
```
