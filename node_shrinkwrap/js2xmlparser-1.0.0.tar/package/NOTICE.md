js2xmlparser  
Copyright (C) 2012 Michael Kourlas and other contributors
