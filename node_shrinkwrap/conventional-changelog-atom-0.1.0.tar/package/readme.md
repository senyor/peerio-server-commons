#  [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url] [![Coverage Status][coveralls-image]][coveralls-url]

> [conventional-changelog](https://github.com/ajoslin/conventional-changelog) [atom](https://github.com/atom/atom) preset


See [convention](convention.md)


[npm-image]: https://badge.fury.io/js/conventional-changelog-atom.svg
[npm-url]: https://npmjs.org/package/conventional-changelog-atom
[travis-image]: https://travis-ci.org/stevemao/conventional-changelog-atom.svg?branch=master
[travis-url]: https://travis-ci.org/stevemao/conventional-changelog-atom
[daviddm-image]: https://david-dm.org/stevemao/conventional-changelog-atom.svg?theme=shields.io
[daviddm-url]: https://david-dm.org/stevemao/conventional-changelog-atom
[coveralls-image]: https://coveralls.io/repos/stevemao/conventional-changelog-atom/badge.svg
[coveralls-url]: https://coveralls.io/r/stevemao/conventional-changelog-atom
