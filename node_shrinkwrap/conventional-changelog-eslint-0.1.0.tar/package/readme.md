#  [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url] [![Coverage Status][coveralls-image]][coveralls-url]

> [conventional-changelog](https://github.com/ajoslin/conventional-changelog) [eslint](https://github.com/eslint/eslint) preset


See [convention](convention.md)


[npm-image]: https://badge.fury.io/js/conventional-changelog-eslint.svg
[npm-url]: https://npmjs.org/package/conventional-changelog-eslint
[travis-image]: https://travis-ci.org/stevemao/conventional-changelog-eslint.svg?branch=master
[travis-url]: https://travis-ci.org/stevemao/conventional-changelog-eslint
[daviddm-image]: https://david-dm.org/stevemao/conventional-changelog-eslint.svg?theme=shields.io
[daviddm-url]: https://david-dm.org/stevemao/conventional-changelog-eslint
[coveralls-image]: https://coveralls.io/repos/stevemao/conventional-changelog-eslint/badge.svg
[coveralls-url]: https://coveralls.io/r/stevemao/conventional-changelog-eslint
