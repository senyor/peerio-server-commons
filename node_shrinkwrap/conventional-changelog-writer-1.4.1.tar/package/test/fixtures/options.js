module.exports = {
  mainTemplate: '{{date2}}template'
};
