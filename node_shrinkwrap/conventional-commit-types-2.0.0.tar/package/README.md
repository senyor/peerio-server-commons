# conventional-commit-types

List of conventional commit types.

* https://github.com/commitizen/cz-cli
* https://docs.google.com/document/d/1QrDFcIiPjSLDn3EL15IJygNPiHORgU1_OOAqWjiDU5Y/edit#heading=h.8gbcep5xnw19

Created for https://github.com/adjohnson916/conventional-commit-types-cli.

